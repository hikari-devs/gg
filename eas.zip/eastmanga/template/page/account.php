<?php
/*
* -------------------------------------------------------------------------------------
* @author: EasTheme Team
* @author URI: https://eastheme.com
* @copyright: (c) 2020 EasTheme. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 1.0.1
*
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
global $current_user, $wp_roles, $wpdb;
wp_get_current_user();
$user_id	= get_current_user_id();
$first_name = get_user_meta($user_id, 'first_name', true);
$last_name	= get_user_meta($user_id, 'last_name', true);
$readingmode	= get_user_meta($user_id, 'reading_mode', true);
$thememode	= get_user_meta($user_id, 'theme_mode', true);
$list		= get_user_meta($user_id, $wpdb->prefix .'favorites_count', true);
$view		= get_user_meta($user_id, $wpdb->prefix .'user_view_count', true);
?>

<div id="content" class="content-separate">
   <div id="primary" class="content-area">
      <main id="main" class="site-main post-body widget_senction" role="main">
         <div class="relat post-show">

	 <div id="favorites">
            <?php
               echo '<h3 class="txacc">'.__d('Favorites').'</h3>';
                 EastManga::east_favorites_content($user_id, array('manga'), '18', '_east_favorites', 'favorites');
								 ?>
							 </div>

							 <div id="history" class="tab_box">
								   <h3 class="txacc"><?php _d('History'); ?></h3>
												  <?php EastManga::east_history_content($user_id); ?>
											</div>

	 <div id="account" class="tab_box">
            <h3 class="txacc"><?php _d('Account Setting'); ?></h3>
						<div id="update_notice"></div>
            <form id="update_user_page" class="update_profile">
               <div id="general">
                  <fieldset class="form-email">
                     <label for="email"><?php _d('E-mail'); ?></label>
                     <input type="text" id="email" name="email" value="<?php the_author_meta('user_email', $current_user->ID ); ?>" disabled />
                  </fieldset>
                  <fieldset class="from-first-name min fix">
                     <label for="first-name"><?php _d('First name'); ?></label>
                     <input type="text" id="first-name" name="first-name" value="<?php the_author_meta('first_name', $current_user->ID ); ?>" />
                  </fieldset>
                  <fieldset class="form-last-name min">
                     <label for="last-name"><?php _d('Last name'); ?></label>
                     <input type="text" id="last-name" name="last-name" value="<?php the_author_meta('last_name', $current_user->ID ); ?>" />
                  </fieldset>
									<fieldset class="from-reading-mode min fix">
										 <label for="reading-mode"><?php _d('Reading Mode'); ?></label>
										 <select name="reading-mode" id="reading-mode">
											 <option>Default</option>
											 <option value="list" <?php selected( $readingmode, 'list' ); ?>>List</option>
											 <option value="paged" <?php selected( $readingmode, 'paged' ); ?>>Paged</option>
										 </select>
									</fieldset>
									<fieldset class="from-reading-mode min">
										 <label for="theme-mode"><?php _d('Theme Mode'); ?></label>
										 <select name="theme-mode" id="theme-mode">
											 <option>Default</option>
											 <option value="light" <?php selected( $thememode, 'light' ); ?>>Light</option>
											 <option value="dark" <?php selected( $thememode, 'dark' ); ?>>Dark</option>
										 </select>
									</fieldset>
               </div>
               <div id="password">
                  <fieldset class="form-pass1 min fix">
                     <label for="pass1"><?php _d('New password *'); ?></label>
                     <input type="password" id="pass1" name="pass1" />
                  </fieldset>
                  <fieldset class="form-pass2 min">
                     <label for="pass2"><?php _d('Repeat password *'); ?></label>
                     <input type="password" id="pass2" name="pass2" />
                  </fieldset>
               </div>
               <fieldset class="form-submit">
                  <input name="updateuser" type="submit" id="updateuser" class="submit button" value="<?php _d('Update account'); ?>" />
                  <?php wp_nonce_field('update-user','update-user-nonce')?>
               </fieldset>
            </form>
					</div>

            <script type='text/javascript'>
               jQuery(document).ready(function($) {
                 $('#update_user_page').submit(function(){
                   $('#message').html('<div class="sms"><div class="updating"><i class="icons-spinner9 loading"></i> '+ easthemeajax.updating + '</div></div>');
                   $.ajax({
                     type:'POST',
                     url:easthemeajax.url + '?action=east_update_user',
                     data:$(this).serialize()
                   })
                   .done(function(data){
                     $('#update_notice').html('<div class="txes">' + data + '</div>');
                   });
                   return false;
                 });
               });
            </script>

         </div>
      </div>

      <div id="sidebar">
         <div class="senc">
            <div class="side-account">
							<ul class="idTabs amenu">
												 <li class=""><a href="#favorites" class="selected">Favorites</a></li>
												 <li><a href="#history">History</a></li>
												 <li><a href="#account">Account Settings</a></li>
												 </ul>
											 </div>
										</div>
								 </div>
							</div>

<?php get_footer(); ?>
