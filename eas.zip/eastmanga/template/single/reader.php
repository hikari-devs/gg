<?php
/*
* -------------------------------------------------------------------------------------
* @author: EasTheme Team
* @author URI: https://eastheme.com
* @copyright: (c) 2020 EasTheme. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 1.0.1
*
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

if ( have_posts() ) : while ( have_posts() ) : the_post();
$series = get_post_meta(get_the_ID(), 'east_series', true);
$content = get_content_chapter_img(get_the_ID(), 1);
east_process_history(get_the_ID());
?>
<div class="player-area widget_senction">
   <header class="entry-header info_episode widget_senction">
      <div class="lm">
         <?php the_title( '<h1 class="entry-title" itemprop="name">', '</h1>' ); ?>
         <div class="sbdbti">
            <span class="epx"><i class="fas fa-book-open"></i> <a href="<?php echo get_the_permalink($series); ?>"> <?php echo get_the_title($series); ?></a></span>
         </div>
         <span class="year"><?php _d('Posted By'); ?> <?php $author_id = get_post_field( 'post_author', get_the_ID() ); echo get_the_author_meta('user_nicename', $author_id); ?> - <?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . __d(' ago'); ?></span>
         <div class="desch">  <?php _d('Happy reading manga'); ?> <b><?php the_title(); ?></b> , <?php _d("don't forget to click the like and share button"); ?>. Manga <b><?php echo get_the_title($series); ?></b> <?php _d('always updated on'); ?> <b><?php bloginfo('name'); ?></b>. <?php _d("Don't forget to read other manga updates. List of manga collections"); ?> <b><?php bloginfo('name'); ?></b> <?php _d('is on the Manga List menu'); ?>.</div>
      </div>
   </header>
</div>
   <div class="sharesection sharech">
      <center>
         <b><?php _d('Share to your friends!');?></b>
         <?php east_social_share(get_the_ID()); ?>
      </center>
   </div>
<?php get_ads('adsbeforenavtop','ads_info'); ?>
<?php EastManga::chapter_navigation(get_the_ID(), $content); ?>
<div class="clear"></div>
<?php get_ads('adsbottomtitle','ads_info'); ?>
<div id="loaderch" class="load_slider flashit" style="display: block;">Loading..</div>
<div class="reader-area" style="display:none">
<?php
get_chapter_image(get_the_ID());
endwhile; endif; wp_reset_query(); ?>
</div>

<?php get_ads('adsbottomplayer','ads_info'); ?>
<?php EastManga::chapter_navigation(get_the_ID(), $content); ?>
<div class="clear"></div>
<div class="whites lats displayblock">
   <div class="sharesection">
      <center>
         <b><?php _d('Share to your friends!');?></b>
         <?php east_social_share(get_the_ID()); ?>
      </center>
   </div>
</div>
<script>
$(function () {
 ch_image = $.reader({ array: <?php echo json_encode((object)$content); ?> });
});

$.each(["#loaderch"], function (e, s) {
	1 <= $(s).length && ($("#content").ready(function () {
		$(s).css("display", "none")
		$(".reader-area").css("display", "block")
	}), $(".content").load(function () {
		$(s).css("display", "none")
		$(".reader-area").css("display", "block")
	}))
});
</script>
