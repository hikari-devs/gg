<?php
/*
* -------------------------------------------------------------------------------------
* @author: EasTheme Team
* @author URI: https://eastheme.com
* @copyright: (c) 2020 EasTheme. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 1.0.1
*
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function manga_series_metabox() {

wp_nonce_field( 'east_manga_meta', 'east_manga_meta_nonce' );

echo "<div class='eastheme-meta-info'>";
echo "<div class='loadingmal' style='display:none'><i class='fa fa-spinner fa-spin'></i></div>";
echo "<div class='metabox-holder east-meta-metabox-common-fields meta-info-series'>";

					 $meta = array(

						 array(
								 'name'   => 'Generate Data',
								 'id'     => 'east_malid',
								 'type'   => 'generator',
								 'ldesc'   => __d('Generate data from myanimelist.net')
						 ),
						 array(
								 'name'   => 'Cover',
								 'id'     => 'east_cover',
								 'type'   => 'upload',
								 'ldesc'   => __d('Input cover')
						 ),
						 array(
								 'name'   => 'Thumbnail',
								 'id'     => 'east_thumbnail',
								 'type'   => 'upload',
								 'ldesc'   => __d('Input thumbnail')
						 ),
						 array(
								 'name'   => 'Japanese',
								 'id'     => 'east_japanese',
								 'type'   => 'text',
								 'ldesc'   => __d('Input japanese title')
						 ),
						 array(
								 'name'   => 'Synonyms',
								 'id'     => 'east_synonyms',
								 'type'   => 'text',
								 'ldesc'   => __d('Input synonyms title')
						 ),
						 array(
								 'name'   => 'English',
								 'id'     => 'east_english',
								 'type'   => 'text',
								 'ldesc'   => __d('Input english title')
						 ),
						 array(
								 'name'   => 'Project?',
								 'id'     => 'east_project',
								 'type'   => 'select',
								 'ldesc'   => __d('Select project'),
								 'option' => array(
									 '0' => 'No',
									 '1' => 'Yes'
								 )
						 ),
						 array(
								 'name'   => 'Hot Manga?',
								 'id'     => 'east_hot',
								 'type'   => 'select',
								 'ldesc'   => __d('Select hot'),
								 'option' => array(
									 '0' => 'No',
									 '1' => 'Yes'
								 )
						 ),
						 array(
								 'name'   => 'Status',
								 'id'     => 'east_status',
								 'type'   => 'select',
								 'ldesc'   => __d('Select status'),
								 'option' => array(
									 'Publishing' => 'Publishing',
									 'Finished' => 'Finished'
								 )
						 ),
						 array(
								 'name'   => 'Type',
								 'id'     => 'east_type',
								 'type'   => 'select',
								 'ldesc'   => __d('Select type'),
								 'option' => array(
									 'Manga' => 'Manga',
									 'Manhwa' => 'Manhwa',
									 'Manhua' => 'Manhua'
								 )
						 ),
						 array(
								 'name'   => 'Rating',
								 'id'     => 'east_score',
								 'id2'    => 'east_users',
								 'type'   => 'dual_text',
								 'ldesc'   => __d('Averages / votes')
						 ),
						 array(
								 'name'   => 'Serialization',
								 'id'     => 'east_serialization',
								 'type'   => 'text',
								 'ldesc'   => __d('Input serialization')
						 ),
						 array(
								 'name'   => 'Release Date',
								 'id'     => 'east_date',
								 'type'   => 'text',
								 'ldesc'   => __d('Input release date')
						 ),
						 array(
								 'name'   => 'Author',
								 'id'     => 'east_author',
								 'type'   => 'text',
								 'ldesc'   => __d('Input author')
						 ),
						 array(
								 'name'   => 'Total Chapter',
								 'id'     => 'east_totalchapter',
								 'type'   => 'text',
								 'ldesc'   => __d('Input total chapter')
						 ),
						 array(
								 'name'   => 'Total Volume',
								 'id'     => 'east_totalvolume',
								 'type'   => 'text',
								 'ldesc'   => __d('Input total volume')
						 ),

					 );


	   	new EastMetaField($meta);

			  echo '</div></div>';


		}

		function east_chapter_meta_content() {

			wp_nonce_field( 'east_chapter_meta', 'east_chapter_meta_nonce' );

			$meta = array(
				array(
						'name'   => 'Chapter',
						'id'     => 'east_chapter',
						'type'   => 'text',
						'ldesc'   => __d('Input chapter')
				),
				array(
						'name'   => 'Manga Series',
						'id'     => 'east_series',
						'type'   => 'select_query',
						'ldesc'   => __d('Select manga series'),
						'post_type' => 'manga'
				),
				array(
						'name'   => 'Download Link',
						'id'     => 'east_download',
						'type'   => 'text',
						'ldesc'   => __d('Input download link')
				),
			);

			new EastMetaField($meta);

		}
