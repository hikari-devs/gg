<?php
/*
* -------------------------------------------------------------------------------------
* @author: EasTheme Team
* @author URI: https://eastheme.com
* @copyright: (c) 2020 EasTheme. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 1.0.1
*
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function manga() {

  $labels = array(
    'name'                => _x( 'Manga', 'Post Type General Name', 'text_domain' ),
    'singular_name'       => _x( 'Manga', 'Post Type Singular Name', 'text_domain' ),
    'menu_name'           => __( 'Manga Series', 'text_domain' ),
    'name_admin_bar'      => __( 'Manga', 'text_domain' ),
    'parent_item_colon'   => __( 'Parent Manga :', 'text_domain' ),
    'all_items'           => __( 'All Manga', 'text_domain' ),
    'add_new_item'        => __( 'Add New Manga', 'text_domain' ),
    'add_new'             => __( 'Add New', 'text_domain' ),
    'new_item'            => __( 'New Manga', 'text_domain' ),
    'edit_item'           => __( 'Edit Manga', 'text_domain' ),
    'update_item'         => __( 'Update Manga', 'text_domain' ),
    'view_item'           => __( 'View Manga', 'text_domain' ),
    'search_items'        => __( 'Search Manga', 'text_domain' ),
    'not_found'           => __( 'Not found', 'text_domain' ),
    'not_found_in_trash'  => __( 'Not found in Trash', 'text_domain' ),
  );
  $args = array(
    'label'               => __( 'Manga', 'text_domain' ),
    'description'         => __( 'Manga', 'text_domain' ),
    'labels'              => $labels,
    'supports'            => array( 'title', 'editor', 'thumbnail', 'comments', ),
    'taxonomies'          => array( 'category' , 'post_tag'),
    'hierarchical'        => true,
    'public'              => true,
    'show_ui'             => true,
    'show_in_menu'        => true,
    'menu_position'       => 6,
    'menu_icon'           => 'dashicons-list-view',
    'show_in_admin_bar'   => true,
    'show_in_nav_menus'   => true,
    'can_export'          => true,
    'has_archive'         => true,
    'exclude_from_search' => false,
    'publicly_queryable'  => true,
    'capability_type'     => 'post',
  );
  register_post_type( 'manga', $args );

}

add_action( 'init', 'manga', 0 );

function blog() {

  $labels = array(
    'name'                => _x( 'Blog', 'Post Type General Name', 'text_domain' ),
    'singular_name'       => _x( 'Blog', 'Post Type Singular Name', 'text_domain' ),
    'menu_name'           => __( 'Blog', 'text_domain' ),
    'name_admin_bar'      => __( 'Blog', 'text_domain' ),
    'parent_item_colon'   => __( 'Parent Blog :', 'text_domain' ),
    'all_items'           => __( 'All Blog', 'text_domain' ),
    'add_new_item'        => __( 'Add New Blog', 'text_domain' ),
    'add_new'             => __( 'Add New', 'text_domain' ),
    'new_item'            => __( 'New Blog', 'text_domain' ),
    'edit_item'           => __( 'Edit Blog', 'text_domain' ),
    'update_item'         => __( 'Update Blog', 'text_domain' ),
    'view_item'           => __( 'View Blog', 'text_domain' ),
    'search_items'        => __( 'Search Blog', 'text_domain' ),
    'not_found'           => __( 'Not found', 'text_domain' ),
    'not_found_in_trash'  => __( 'Not found in Trash', 'text_domain' ),
  );
  $args = array(
    'label'               => __( 'Blog', 'text_domain' ),
    'description'         => __( 'Blog', 'text_domain' ),
    'labels'              => $labels,
    'supports'            => array( 'title', 'editor', 'thumbnail', 'comments', ),
    'taxonomies'          => array(  'post_tag'),
    'hierarchical'        => true,
    'public'              => true,
    'show_ui'             => true,
    'show_in_menu'        => true,
    'menu_position'       => 6,
    'menu_icon'           => 'dashicons-welcome-write-blog',
    'show_in_admin_bar'   => true,
    'show_in_nav_menus'   => true,
    'can_export'          => true,
    'has_archive'         => true,
    'exclude_from_search' => false,
    'publicly_queryable'  => true,
    'capability_type'     => 'post',
  );
  register_post_type( 'blog', $args );

}

add_action( 'init', 'blog', 0 );

function blog_category() {
	$labels = array(
		'name'              => _x( 'Blog Category', 'taxonomy general name', 'textdomain' ),
		'singular_name'     => _x( 'Blog Category', 'taxonomy singular name', 'textdomain' ),
		'search_items'      => __( 'Search Blog Category', 'textdomain' ),
		'all_items'         => __( 'All Blog Category', 'textdomain' ),
		'parent_item'       => __( 'Parent Blog Category', 'textdomain' ),
		'parent_item_colon' => __( 'Parent Blog Category:', 'textdomain' ),
		'edit_item'         => __( 'Edit Blog Category', 'textdomain' ),
		'separate_items_with_commas' => __( 'Separate Blog Category with commas', 'textdomain' ),
		'update_item'       => __( 'Update Blog Category', 'textdomain' ),
		'add_new_item'      => __( 'Add New Blog Category', 'textdomain' ),
		'new_item_name'     => __( 'New Blog Category Name', 'textdomain' ),
		'menu_name'         => __( 'Blog Category', 'textdomain' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'blog-category' ),
	);

	register_taxonomy( 'blog-category', array( 'blog' ), $args );
}

add_action('init', 'blog_category', 0 );

function eastgenres() {
	$labels = array(
		'name'              => _x( 'Genres', 'taxonomy general name', 'textdomain' ),
		'singular_name'     => _x( 'Genre', 'taxonomy singular name', 'textdomain' ),
		'search_items'      => __( 'Search Genres', 'textdomain' ),
		'all_items'         => __( 'All Genres', 'textdomain' ),
		'parent_item'       => __( 'Parent Genre', 'textdomain' ),
		'parent_item_colon' => __( 'Parent Genre:', 'textdomain' ),
		'edit_item'         => __( 'Edit Genre', 'textdomain' ),
		'separate_items_with_commas' => __( 'Separate Genre with commas', 'textdomain' ),
		'update_item'       => __( 'Update Genre', 'textdomain' ),
		'add_new_item'      => __( 'Add New Genre', 'textdomain' ),
		'new_item_name'     => __( 'New Genre Name', 'textdomain' ),
		'menu_name'         => __( 'Genre', 'textdomain' ),
	);

	$args = array(
		'hierarchical'      => false,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'genre' ),
	);

	register_taxonomy( 'genre', array( 'manga' ), $args );
}

add_action('init', 'eastgenres', 0 );

function eastyears() {
	$labels = array(
		'name'              => _x( 'Years', 'taxonomy general name', 'textdomain' ),
		'singular_name'     => _x( 'Years', 'taxonomy singular name', 'textdomain' ),
		'search_items'      => __( 'Search Years', 'textdomain' ),
		'all_items'         => __( 'All Years', 'textdomain' ),
		'parent_item'       => __( 'Parent Years', 'textdomain' ),
		'parent_item_colon' => __( 'Parent Years:', 'textdomain' ),
		'edit_item'         => __( 'Edit Years', 'textdomain' ),
		'separate_items_with_commas' => __( 'Separate Years with commas', 'textdomain' ),
		'update_item'       => __( 'Update Years', 'textdomain' ),
		'add_new_item'      => __( 'Add New Years', 'textdomain' ),
		'new_item_name'     => __( 'New Years Name', 'textdomain' ),
		'menu_name'         => __( 'Years', 'textdomain' ),
	);

	$args = array(
		'hierarchical'      => false,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'years' ),
	);

	register_taxonomy( 'years', array( 'manga' ), $args );
}

add_action('init', 'eastyears', 0 );

if (!function_exists('post_type_post')) {
	function post_type_post() {
		global $wp_post_types;
		$labels = &$wp_post_types['post']->labels;
		$labels->name = 'Chapter';
		$labels->singular_name = 'Chapter';
		$labels->add_new = 'Add Chapter';
		$labels->add_new_item = 'Add Chapter';
		$labels->edit_item = 'Edit Chapter';
		$labels->new_item = 'Chapter';
		$labels->view_item = 'View Chapter';
		$labels->search_items = 'Search Chapter';
		$labels->not_found = 'No Episode found';
		$labels->menu_icon = 'dashicons-book';
		$labels->not_found_in_trash = 'No Chapter found in Trash';
		$labels->all_items = 'All Chapter';
		$labels->menu_name = 'Chapter';
		$labels->name_admin_bar = 'Chapter';
	}
}

function category_to_manga_category() {
		global $wp_taxonomies;

		$cat                            = $wp_taxonomies['category'];
		$cat->label                     = __( 'Manga Category', 'eastheme-core' );
		$cat->labels->singular_name     = __( 'Manga Category', 'eastheme-core' );
		$cat->labels->name              = $cat->label;
		$cat->labels->menu_name         = $cat->label;
		$cat->labels->search_items      = __( 'Search', 'eastheme-core' ) . ' ' . $cat->label;
		$cat->labels->popular_items     = __( 'Popular', 'eastheme-core' ) . ' ' . $cat->label;
		$cat->labels->all_items         = __( 'All', 'eastheme-core' ) . ' ' . $cat->label;
		$cat->labels->parent_item       = __( 'Parent', 'eastheme-core' ) . ' ' . $cat->labels->singular_name;
		$cat->labels->parent_item_colon = __( 'Parent', 'eastheme-core' ) . ' ' . $cat->labels->singular_name . ':';
		$cat->labels->edit_item         = __( 'Edit', 'eastheme-core' ) . ' ' . $cat->labels->singular_name;
		$cat->labels->update_item       = __( 'Update', 'eastheme-core' ) . ' ' . $cat->labels->singular_name;
		$cat->labels->add_new_item      = __( 'Add new', 'eastheme-core' ) . ' ' . $cat->labels->singular_name;
		$cat->labels->new_item_name     = __( 'New', 'eastheme-core' ) . ' ' . $cat->labels->singular_name;

	}

add_action( 'init', 'category_to_manga_category' );


?>
