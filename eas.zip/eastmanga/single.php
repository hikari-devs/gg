<?php
/*
* -------------------------------------------------------------------------------------
* @author: EasTheme
* @author URI: https://eastheme.com
* @copyright: (c) 2019 EasTheme. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 1.0.1
*
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$related = get_option('relatedanime');
$series = get_post_meta(get_the_ID(), 'east_series', true);
get_ads('sadsheader');
?>
<div id="infoarea">
   <div id="shadow"></div>
   <div class="plyexpand"></div>
   <div id="primary" class="content-area reader-body">
      <main id="main" class="site-main" role="main">
         <article id="post-<?php the_ID();?>" <?php post_class();?> itemscope="itemscope" itemtype="http://schema.org/Episode">
            <?php  get_template_part('template/single/reader');  ?>
            <?php get_template_part('template/single/info'); ?>
         </article>
         <?php
            east_breadcrumbs_episode(get_the_ID());
            if($related == 1)	{ get_template_part('template/single/related'); }
            get_template_part('template/single/comments'); ?>
      </main>
   </div>
</div>

<?php get_footer(); ?>
